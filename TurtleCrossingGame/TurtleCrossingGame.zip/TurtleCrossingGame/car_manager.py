from turtle import Turtle
import random

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10


class CarManager(Turtle):

    def __init__(self, STARTING_MOVE_DISTANCE, MOVE_INCREMENT):
        super().__init__()
        self.color(COLORS[random.randint(0,5)])
        self.shape('square')
        self.penup()
        self.start = STARTING_MOVE_DISTANCE
        self.increment = MOVE_INCREMENT
        self.ran_y = random.randint(-260, 270)
        self.shapesize(stretch_wid=1, stretch_len=1.5)
        self.goto(280, self.ran_y)
    def move(self):
        self.goto(self.xcor()-self.start, self.ran_y)
    def level_up(self):
        self.start += self.increment

