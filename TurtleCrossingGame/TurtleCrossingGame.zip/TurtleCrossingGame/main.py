import time
from turtle import Screen
from player import Player
from car_manager import CarManager, STARTING_MOVE_DISTANCE, MOVE_INCREMENT
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)
screen.listen()

score_board = Scoreboard()

cars = []
game_is_on = True
play = Player()
i = 0

while game_is_on:
    time.sleep(0.1)
    screen.update()
    if play.ycor() >= 260:
        play.reset()
        score_board.score += 1
        for car in cars:
            car.level_up()
        STARTING_MOVE_DISTANCE += MOVE_INCREMENT
    if i == 6:
        x = CarManager(STARTING_MOVE_DISTANCE, MOVE_INCREMENT)
        cars.append(x)
        i = 0
    for car in cars:
        car.move()
    screen.onkey(play.move,'w')
    for car in cars:
        if play.distance(car) < 20:
            play.reset()
            for car in cars:
                car.clear()
            STARTING_MOVE_DISTANCE = 5
            score_board.score = 0
    i += 1
